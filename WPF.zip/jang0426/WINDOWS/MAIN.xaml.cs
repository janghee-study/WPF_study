﻿namespace jang0426.WINDOWS
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Shapes;
    using System.Windows.Forms;
    using System.Text.RegularExpressions;

    /// <summary>
    /// MAIN.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MAIN : Window
    {
        
        public MAIN()
        {
            InitializeComponent();
        }

        

        public void WORK_Main_Loaded(object sender, RoutedEventArgs e)
        {
            var box = sender as Grid;
            //box.DataContext = Vars.propertyIO;
            box.DataContext = Vars._viewmodel;
        }

        public void Start_Click(object sender, RoutedEventArgs e)
        {
            Vars._counter.Upcount();
            Vars._testcheck.CHECK();
            Vars._counter.Ratecaluration();
        }

        public void File_Click(object sender, RoutedEventArgs e)
        {

            Vars._filemethods.OpenMethod(sender, e);
        }

        private void SET_VOLT(object sender, RoutedEventArgs e)
        {
            Vars._volt.TypeConfirm_VOLT();
            //System.Windows.MessageBox.Show(Vars._viewmodel.speed_LEVEL);
        }

        private void SET_SPEED(object sender, RoutedEventArgs e)
        {
            Vars._volt.TypeConfirm_SPEED();
            //System.Windows.MessageBox.Show(Vars._viewmodel.volt_LEVEL);
        }


        //숫자만 입력받는 핸들러 오류수정
        private void Key_Press(object sender, System.Windows.Input.KeyEventArgs e)
        {
            //if (!(((Key.D0 <= e.Key) && (e.Key <= Key.D9))
            //|| ((Key.NumPad0 <= e.Key) && (e.Key <= Key.NumPad9))
            //|| e.Key == Key.Back))
            //{
            //    System.Windows.MessageBox.Show("FLOAT");
            //    e.Handled = true;
            //}
        }

        private void ON_Click(object sender, RoutedEventArgs e)
        {

            System.Windows.MessageBox.Show(Vars._viewmodel.volt_LEVEL+ " volt  "+ Vars._viewmodel.speed_LEVEL+" m/s \n설정 되었습니다.");

        }

        private void OFF_Click(object sender, RoutedEventArgs e)
        {
            Vars._viewmodel.volt_LEVEL = "0.0";
            Vars._viewmodel.speed_LEVEL = "0.0";

            System.Windows.MessageBox.Show(Vars._viewmodel.volt_LEVEL + " volt  " + Vars._viewmodel.speed_LEVEL + " m/s \n설정 되었습니다.");
        }
    }
}
