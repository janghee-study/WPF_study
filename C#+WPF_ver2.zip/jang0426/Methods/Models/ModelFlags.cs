﻿namespace jang0426.WINDOWS
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Threading.Tasks;


    public class FlagsProperty : PropertyUpdate
    {
        #region Measusred Multimeter's Datas
        /// <summary>
        /// 계측기류에서 측정되어진 결과값 double로 결과를 받고 ValueConverter에 의해 TextBlock에 스트링으로 변경
        /// </summary>

        private bool portmes;
        public bool PortMES
        {
            get { return portmes; }
            set
            {
                portmes = value;
                var Method = MethodBase.GetCurrentMethod().Name.Replace("set_", "");
                Notify(Method);
            }
        }

        private bool portio;
        public bool PortIO
        {
            get { return portio; }
            set
            {
                portio = value;
                var Method = MethodBase.GetCurrentMethod().Name.Replace("set_", "");
                Notify(Method);
            }
        }

        private bool portProgrammer;
        public bool PortProgrammer
        {
            get { return portProgrammer; }
            set
            {
                portProgrammer = value;
                var Method = MethodBase.GetCurrentMethod().Name.Replace("set_", "");
                Notify(Method);
            }
        }

        private bool portDebugger;
        public bool PortDebugger
        {
            get { return portDebugger; }
            set
            {
                portDebugger = value;
                var Method = MethodBase.GetCurrentMethod().Name.Replace("set_", "");
                Notify(Method);
            }
        }

        bool portcomm;
        public bool PortCOMM
        {
            get { return portcomm; }
            set
            {
                portcomm = value;
                var Method = MethodBase.GetCurrentMethod().Name.Replace("set_", "");
                Notify(Method);
            }
        }
        #endregion
    }
}

