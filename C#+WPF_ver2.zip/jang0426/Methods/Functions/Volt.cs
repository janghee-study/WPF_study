﻿namespace jang0426.WINDOWS
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Windows;
    using System.Windows.Input;

    public class Volt : PropertyUpdate
    {
        public void TypeConfirm()
        {
            float voltCut = float.Parse(Vars._viewmodel.volt_LEVEL);

            if (voltCut > 15.0)
            {
                System.Windows.MessageBox.Show("Volt High");
            }
            else if(voltCut < 0.5)
            {
                System.Windows.MessageBox.Show("Volt Low");
            }
            else
            {
                System.Windows.MessageBox.Show("Volt Good");
            }

        }
    }
}
