﻿namespace jang0426.WINDOWS
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Diagnostics;
    using System.IO.Ports;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Controls;
    using System.Windows.Threading;
    using System.Xml;

    using WpfControls.Controls;

    public struct ErrorMessage
    {
        public string HeaderSubject;
        public string HeaderAction;
        public string HeaderCode;
        public string ContentSubject;
        public string ContentAction;
        public string ContentCode;
    }
}
