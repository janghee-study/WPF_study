﻿namespace jang0426.WINDOWS
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Threading;
    using System.Xml;
    using System.ComponentModel;
    using System.Drawing;

    class RecipeInfo
    {
        public double MaxWeigh;
        public double MinWeigh;

        public int DelayTime;
        public int CheckTime;

        public void init()
        {
            MaxWeigh = 0;
            MinWeigh = 0;
            DelayTime = 0;
            CheckTime = 0;
        }
    }

    class ResulteInfo
    {
        public string Resulte;

        public double CurrentWeigh;

        public double MaxWeigh;
        public double MinWeigh;

        public int DelayTime;
        public int CheckTime;

        public string SensorOK;
        public string SensorLOW;
        public string SensorHIGH;

        public string CylinderUP;
        public string CylinderDW;

        public void init()
        {
            Resulte = "";
            CurrentWeigh = 0;
            MaxWeigh = 0;
            MinWeigh = 0;
            DelayTime = 0;
            CheckTime = 0;

            SensorOK = "";
            SensorLOW = "";
            SensorHIGH = "";
            CylinderUP = "";
            CylinderDW = "";
        }
    }

    static class Vars
    {
        #region BackgroundWorkers
        //static public Dictionary<int, BackgroundWorker> WorkerTest = new Dictionary<int, BackgroundWorker>();
        static public BackgroundWorker WorkerTest;
        #endregion

        static public RecipeInfo CurrRecipe = new RecipeInfo();
        static public ResulteInfo CurrResulte = new ResulteInfo();

        static public string startTime = "";
        static public bool completeLoading = true;

        static public string SelectedTheme = "BLACK", Error_Type, Error_Code;
        static public bool Flag_ManagerMode = false, Flag_Check_Machines = true;

        static public FlagsProperty FlagsPort = new FlagsProperty();
        static public bool Flag_Use_IO_Module = false, Flag_Use_COMM = false;

        static public bool Flag_Buzzer_Continuous;
        static public bool Flag_Result_Total, Result_Final;

        static public int listErrorMessage = 0;
        static public ErrorMessage Error_Message = new ErrorMessage();
        //static public LockScreen lockScreen = new LockScreen();


        static public Filemethods _filemethods = new Filemethods();
        static public Counter _counter = new Counter();
        static public Testcheck _testcheck = new Testcheck();
        static public ViewModels _viewmodel = new ViewModels();
        static public Volt  _volt = new Volt();

        
    }
}